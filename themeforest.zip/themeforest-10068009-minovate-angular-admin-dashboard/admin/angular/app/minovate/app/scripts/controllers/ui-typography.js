'use strict';

/**
 * @ngdoc function
 * @name minovateApp.controller:TypographyCtrl
 * @description
 * # TypographyCtrl
 * Controller of the minovateApp
 */
app
  .controller('TypographyCtrl', function ($scope) {
    $scope.page = {
      title: 'Typography',
      subtitle: 'Place subtitle here...'
    };
  });
