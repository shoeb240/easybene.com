'use strict';

app

  .controller('mtTooltipCtrl', function($scope, $timeout, $mdBottomSheet) {

    $scope.page = {
      title: 'Tooltip',
      subtitle: 'Place subtitle here...'
    };

    $scope.demo = {};

  });




