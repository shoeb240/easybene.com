'use strict';

/**
 * @ngdoc function
 * @name minovateApp.controller:MailSingleCtrl
 * @description
 * # MailSingleCtrl
 * Controller of the minovateApp
 */
app
  .controller('MailSingleCtrl', function ($scope) {
    $scope.awesomeThings = [
      'HTML5 Boilerplate',
      'AngularJS',
      'Karma'
    ];
  });
