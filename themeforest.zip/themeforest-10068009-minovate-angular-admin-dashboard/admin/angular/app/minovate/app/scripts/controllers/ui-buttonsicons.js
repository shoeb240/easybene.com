'use strict';

/**
 * @ngdoc function
 * @name minovateApp.controller:ButtonsiconsCtrl
 * @description
 * # ButtonsiconsCtrl
 * Controller of the minovateApp
 */
app
  .controller('ButtonsIconsCtrl', function ($scope) {
     $scope.page = {
      title: 'Buttons & Icons',
      subtitle: 'Place subtitle here...'
    };
  });
