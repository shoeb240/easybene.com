'use strict';

app

  .controller('mtWhiteframeCtrl', function($scope, $timeout, $mdBottomSheet) {

    $scope.page = {
      title: 'Whiteframe',
      subtitle: 'Place subtitle here...'
    };

  });




