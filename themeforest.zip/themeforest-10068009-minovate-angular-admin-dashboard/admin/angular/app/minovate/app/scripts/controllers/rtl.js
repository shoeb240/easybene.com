'use strict';

/**
 * @ngdoc function
 * @name minovateApp.controller:RtlCtrl
 * @description
 * # RtlCtrl
 * Controller of the minovateApp
 */
app
  .controller('RtlCtrl', function ($scope) {
    $scope.page = {
      title: 'RTL Layout',
      subtitle: 'Place subtitle here...'
    };
  });
