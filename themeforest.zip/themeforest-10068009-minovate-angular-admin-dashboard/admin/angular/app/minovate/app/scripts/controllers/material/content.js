'use strict';

app

  .controller('mtContentCtrl', function($scope, $timeout, $mdBottomSheet) {

    $scope.page = {
      title: 'Content',
      subtitle: 'Place subtitle here...'
    };

  });




