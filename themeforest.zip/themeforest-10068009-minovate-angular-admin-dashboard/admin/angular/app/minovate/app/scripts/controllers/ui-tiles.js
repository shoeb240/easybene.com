'use strict';

/**
 * @ngdoc function
 * @name minovateApp.controller:UitilesCtrl
 * @description
 * # UitilesCtrl
 * Controller of the minovateApp
 */
app
  .controller('TilesCtrl', function ($scope) {
    $scope.page = {
      title: 'Tiles',
      subtitle: 'Place subtitle here...'
    };
  });
