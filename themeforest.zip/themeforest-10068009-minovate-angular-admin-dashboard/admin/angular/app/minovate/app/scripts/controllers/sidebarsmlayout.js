'use strict';

/**
 * @ngdoc function
 * @name minovateApp.controller:SidebarsmlayoutCtrl
 * @description
 * # SidebarsmlayoutCtrl
 * Controller of the minovateApp
 */
app
  .controller('SidebarsmlayoutCtrl', function ($scope) {
    $scope.page = {
      title: 'Small Sidebar Layout',
      subtitle: 'Place subtitle here...'
    };
  });
