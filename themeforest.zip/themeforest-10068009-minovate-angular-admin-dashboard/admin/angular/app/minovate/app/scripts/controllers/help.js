'use strict';

/**
 * @ngdoc function
 * @name minovateApp.controller:HelpCtrl
 * @description
 * # HelpCtrl
 * Controller of the minovateApp
 */
app
  .controller('HelpCtrl', function ($scope) {
     $scope.page = {
      title: 'Documentation',
      subtitle: 'Place subtitle here...'
    };
  });
