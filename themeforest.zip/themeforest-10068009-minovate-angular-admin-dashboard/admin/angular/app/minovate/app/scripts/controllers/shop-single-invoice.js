'use strict';

/**
 * @ngdoc function
 * @name minovateApp.controller:ShopSingleInvoiceCtrl
 * @description
 * # ShopSingleInvoiceCtrl
 * Controller of the minovateApp
 */
app
  .controller('SingleInvoiceCtrl', function ($scope) {
    $scope.page = {
      title: 'Single Invoice',
      subtitle: 'Place subtitle here...'
    };
  });
