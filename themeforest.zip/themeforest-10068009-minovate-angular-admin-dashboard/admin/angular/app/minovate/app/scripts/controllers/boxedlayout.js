'use strict';

/**
 * @ngdoc function
 * @name minovateApp.controller:BoxedlayoutCtrl
 * @description
 * # BoxedlayoutCtrl
 * Controller of the minovateApp
 */
app
  .controller('BoxedlayoutCtrl', function ($scope) {
    $scope.page = {
      title: 'Boxed Layout',
      subtitle: 'Place subtitle here...'
    };
  });
