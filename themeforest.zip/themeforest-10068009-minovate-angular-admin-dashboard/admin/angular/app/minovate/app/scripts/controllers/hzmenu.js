'use strict';

/**
 * @ngdoc function
 * @name minovateApp.controller:HzmenuCtrl
 * @description
 * # HzmenuCtrl
 * Controller of the minovateApp
 */
app
  .controller('HzmenuCtrl', function ($scope) {
     $scope.page = {
      title: 'Horizontal menu Layout',
      subtitle: 'Place subtitle here...'
    };
  });
